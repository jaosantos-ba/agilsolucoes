# Emprestimo System

Projeto base organizado para futura evolução do sistema de captação de empréstimos.

## Como usar
1. Ajuste `backend/config/appConfig.js`
2. Coloque as imagens em `frontend/assets/img/`
3. Abra `frontend/index.html` no navegador ou publique essa pasta em sua hospedagem estática

## Observação
A estrutura já deixa separado frontend, backend, banco e documentação para crescimento futuro.
