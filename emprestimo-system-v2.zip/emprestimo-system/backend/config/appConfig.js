const CONFIG = {
  whatsappNumber: "5571999999999",
  appsScriptUrl: "COLE_AQUI_SUA_URL_DO_GOOGLE_APPS_SCRIPT",
  redirectToWhatsApp: true
};